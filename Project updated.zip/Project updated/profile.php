<!DOCTYPE html>
<html lang="en">
    <head>
        <?php

            session_start();

            $host = "localhost";
            $username = "root";
            $password = "";
            $dbname = "instructorprofile";

            // creating a connection to the XAMPP database
            $con = mysqli_connect($host, $username, $password, $dbname);

            // to ensure that the connection is made
            if (!$con)
            {
                die("Connection failed!" . mysqli_connect_error());
            }

            if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && isset($_SESSION['default']) == false) {
                echo "Logged In " . $_SESSION['loggedIn'] . "<br>";
                echo "UserID " . $_SESSION['userID'] . "<br>";


                $id = $_SESSION['userID'];
                $sql = "SELECT * FROM profile WHERE id = '$id'";

                // Send the query to the database
                $rs = mysqli_query($con, $sql);

                // Check if the query was successful and if a row was returned
                if ($rs && mysqli_num_rows($rs) > 0) {
                    $row = mysqli_fetch_assoc($rs);

                    $_SESSION['fullName'] = $row['fullName'];
                    $_SESSION['bio'] = $row['bio'];
                    $_SESSION['fav'] = $row['fav'];
                    $_SESSION['availabilty'] = $row['availability'];
                    $_SESSION['picture'] = $row['picture'];

                    $_SESSION['default'] = true;
                    $_SESSION['userID1'] = $row['id'];
                    $_SESSION['fullName1'] = $row['fullName'];
                    $_SESSION['bio1'] = $row['bio'];
                    $_SESSION['fav1'] = $row['fav'];
                    $_SESSION['availabilty1'] = $row['availability'];
                    $_SESSION['picture1'] = $row['picture'];
                }


            } elseif (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && isset($_SESSION['default']) == true) {
                echo "Logged In + Default" . $_SESSION['loggedIn'] . "<br>";
                echo "UserID " . $_SESSION['userID'] . "<br>";
                echo "UserID1 " . $_SESSION['userID1'] . "<br>";


                //$id = $_SESSION['userID'];
                //$sql = "SELECT * FROM profile WHERE id = '$id'";
                //echo "SQL Query: " . $sql . "<br>";

                //// Send the query to the database
                //$rs = mysqli_query($con, $sql);

                //// Check if the query was successful and if a row was returned
                //if ($rs && mysqli_num_rows($rs) > 0) {
                //    $row = mysqli_fetch_assoc($rs);

                //    $_SESSION['userID'] = $row['id'];
                //    echo $_SESSION['userID'] . "<br>";
                //    $_SESSION['fullName'] = $row['fullName'];
                //    echo $_SESSION['fullName'] . "<br>";
                //    $_SESSION['bio'] = $row['bio'];
                //    $_SESSION['fav'] = $row['fav'];
                //    $_SESSION['availabilty'] = $row['availability'];
                //    $_SESSION['picture'] = $row['picture'];
                //}


            } elseif (isset($_SESSION['default']) == true && $_SESSION['default'] == true) {
                echo "Default " . $_SESSION['default'] . "<br>";
                echo "UserID1 " . $_SESSION['userID1'] . "<br>";


                //$id = $_SESSION['userID'];
                //$sql = "SELECT * FROM profile WHERE id = '$id'";
                //echo "SQL Query: " . $sql . "<br>";

                //// Send the query to the database
                //$rs = mysqli_query($con, $sql);

                //// Check if the query was successful and if a row was returned
                //if ($rs && mysqli_num_rows($rs) > 0) {
                //    $row = mysqli_fetch_assoc($rs);

                //    $_SESSION['userID'] = $row['id'];
                //    echo $_SESSION['userID'] . "<br>";
                //    $_SESSION['fullName'] = $row['fullName'];
                //    echo $_SESSION['fullName'] . "<br>";
                //    $_SESSION['bio'] = $row['bio'];
                //    $_SESSION['fav'] = $row['fav'];
                //    $_SESSION['availabilty'] = $row['availability'];
                //    $_SESSION['picture'] = $row['picture'];
                //}


            } else {
                $_SESSION['default'] = true;

                echo $_SESSION['default'] . "<br>";

                $sql = "SELECT * FROM profile WHERE id = 1";

                // Send the query to the database
                $rs = mysqli_query($con, $sql);
                // Check if the query was successful and if a row was returned
                if ($rs && mysqli_num_rows($rs) > 0) {
                    $row = mysqli_fetch_assoc($rs);

                    $_SESSION['userID1'] = $row['id'];
                    $_SESSION['fullName1'] = $row['fullName'];
                    $_SESSION['bio1'] = $row['bio'];
                    $_SESSION['fav1'] = $row['fav'];
                    $_SESSION['availabilty1'] = $row['availability'];
                    $_SESSION['picture1'] = $row['picture'];

                    echo "Default " . $_SESSION['default'];
                    echo "UserID1 " . $_SESSION['userID1'] . "<br>";
                }


            }




        ?>

        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="css/website.css" />
        <script src="instructorScript.js"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Montserrat&family=Roboto:wght@300;400;700&display=swap" rel="stylesheet" />
        <!-- <script defer src="js/carousel.js"></script> -->
        <title>Healthy Hawks</title>
    </head>
    <body>
        <div class="navigation-container">
            <img src="images/logohh-smallcopy.png" alt="#" /><!--This will be replaced with an logo-->
            <nav class="site-traverse">
                <ul>
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="#instructors">Instructors</a>
                    </li>
                    <li>
                        <a href="exercises.php">Exercises</a>
                    </li>
                </ul>
            </nav>
            <nav class="login-regis">
                <ul>
                    <li>
                        <a href="regCode.php">Register</a>
                    </li>
                </ul>
            </nav>
        </div>

        <div class="mainInstuctorDiv">

            <div class="picName">
                <!-- Profile Picture -->
                <div class="profPic">
                    <!-- ... Profile picture code ... -->
                    <div class="profile-picture">
                        <img class="profilePic" src="images/defaultProfilePic.png" id="profile-img" alt="Profile Picture" />
                        <br>
                        <input type="file" id="file-upload" accept="image/*" onchange="previewFile()" />
                    </div>
                    <label for="file-upload" class="custom-file-upload">Click To Update Photo</label>
                    <button class="save-button" data-column="picture">Save Picture</button>

                    <!--<div>
                        <a href="profileClientSide.html" class="profClient">View From Trainer Side</a>-->
                        <!--<a href="#profileClientSide.html">View From Client Side</a>-->
                    <!--</div>-->
                    <!-- JavaScript code to update the profile picture -->
                    <script>
                        function previewFile() {
                            const preview = document.querySelector('#profile-img');
                            const file = document.querySelector('#file-upload').files[0];
                            const reader = new FileReader();

                            reader.addEventListener("load", function () {
                                // convert image file to base64 string
                                preview.src = reader.result;
                                printBinaryValue(reader.result); // Call the function to print the binary value
                            }, false);

                            if (file) {
                                reader.readAsDataURL(file);
                            }
                        }


                        function printBinaryValue(imageData) {
                            // Remove the data URL prefix
                            const base64String = imageData.replace(/^data:image\/(png|jpg|jpeg);base64,/, "");

                            // Convert the base64 string to binary
                            const binaryValue = atob(base64String);

                            // Print the binary value to the console
                            console.log(binaryValue);
                        }
                    </script>
                </div>

                <!-- Trainer Name -->
                <div class="profile-info">
                    <?php
                    if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && $_SESSION['userID'] == $_SESSION['userID1']) {
                            $fullName = $_SESSION['fullName'];
                            print "<h1 id='name'>$fullName</h1>";

                    } else {
                        $fullName = $_SESSION['fullName1'];
                        print "<h1 id='name'>$fullName</h1>";
                        }

                    ?>
                </div>

                <hr>

            </div>

            <div class="changeTrainer">
                <button class="prevTrainer" onclick="prevT()">Previous Trainer</button>
                <button class="nextTrainer" onclick="nextT()">Next Trainer</button>


                <script>
                    function prevT() {
                        // Send an AJAX request to a PHP file to fetch the next trainer details
                        var xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                // Handle the response from the PHP file
                                var response = this.responseText;
                                if (response.trim() === 'success') {
                                    // Redirect to the profile.php page
                                    window.location.href = 'profile.php';
                                }
                            }
                        };
                        xhttp.open("GET", "prevTrainer.php", true);
                        xhttp.send();
                    }

                    function nextT() {
                        // Send an AJAX request to a PHP file to fetch the next trainer details
                        var xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                // Handle the response from the PHP file
                                var response = this.responseText;
                                if (response.trim() === 'success') {
                                    // Redirect to the profile.php page
                                    window.location.href = 'profile.php';
                                }
                            }
                        };
                        xhttp.open("GET", "nextTrainer.php", true);
                        xhttp.send();
                    }
                </script>
            </div>

            <!-- Trainer Bio -->
            <div class="
                    about-me">
                    <hr />

                    <h2>About Me</h2>
                    <p class="aboutMeText" id="about-me-display">Enter information about yourself</p>
                    <textarea class="aboutMeText" maxlength="500" id="about-me-edit" placeholder="Enter information about yourself"></textarea>

                <?php
                        if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && $_SESSION['userID'] == $_SESSION['userID1']) {
                            print "<button id='edit-button'>Edit</button>";
                            print "<button class='save-button' id='save-button' data-column='bio'>Save</button>";

                        }

                ?>

                    <script>
                    const displayElement = document.getElementById('about-me-display');
                    const editElement = document.getElementById('about-me-edit');
                    const editButton = document.getElementById('edit-button');
                    const saveButton = document.getElementById('save-button');

                    // Show the edit textarea and hide the display paragraph on edit button click
                    editButton.addEventListener('click', () => {
                        displayElement.style.display = 'none';
                        editElement.style.display = 'block';
                        editElement.value = displayElement.textContent; // Set the initial textarea value to the displayed text
                    });

                    // Save the edited text and switch back to display mode on save button click
                    saveButton.addEventListener('click', () => {
                        displayElement.textContent = editElement.value;
                        displayElement.style.display = 'block';
                        editElement.style.display = 'none';
                    });
                </script>

</div>
            <div class="access">
                <!-- Trainer Hours -->
                <table id="table1">
                    <tr>
                        <th></th>
                        <th>Monday</th>
                        <th>Tuesday</th>
                        <th>Wednesday</th>
                        <th>Thursday</th>
                        <th>Friday</th>
                    </tr>
                    <tr>
                        <td>Morning</td>
                        <td>x</td>
                        <td>x</td>
                        <td>x</td>
                        <td>x</td>
                        <td>x</td>
                    </tr>
                    <tr>
                        <td>Afternoon</td>
                        <td>x</td>
                        <td>x</td>
                        <td>x</td>
                        <td>x</td>
                        <td>x</td>
                    </tr>
                    <tr>
                        <td>Evening</td>
                        <td>x</td>
                        <td>x</td>
                        <td>x</td>
                        <td>x</td>
                        <td>x</td>
                    </tr>
                </table>

                <table id="table2" style="display: none;">
                    <tr>
                        <th></th>
                        <th>Monday</th>
                        <th>Tuesday</th>
                        <th>Wednesday</th>
                        <th>Thursday</th>
                        <th>Friday</th>
                    </tr>
                    <tr>
                        <td>Morning</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                    </tr>
                    <tr>
                        <td>Afternoon</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                    </tr>
                    <tr>
                        <td>Evening</td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                        <td>
                            <input type="checkbox" />
                        </td>
                    </tr>
                </table>

                <?php
                if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && $_SESSION['userID'] == $_SESSION['userID1']) {
                    print "<button id'editButton' onclick='toggleTables()'>Edit</button>";
                    print "<button onclick='updateAvailability()' style='display: none;'>Save</button>";
                }

                ?>
                <script>
                // Show the save button when checkboxes are checked
                var checkboxes = document.querySelectorAll("#table2 input[type='checkbox']");
                checkboxes.forEach(function(checkbox) {
                    checkbox.addEventListener("change", function() {
                        var saveButton = document.querySelector("button");
                        saveButton.style.display = "block";
                    });
                });
                </script>

                <script>
                function toggleTables() {
                    var table1 = document.getElementById("table1");
                    var table2 = document.getElementById("table2");
                    var editButton = document.getElementById("editButton");

                    if (table1.style.display === "none") {
                        table1.style.display = "table";
                        table2.style.display = "none";
                        editButton.innerHTML = "Edit";
                    } else {
                        table1.style.display = "none";
                        table2.style.display = "table";
                        editButton.innerHTML = "Save";
                    }
                }

                function updateAvailability() {
                    var table1 = document.getElementById("table1");
                    var table2 = document.getElementById("table2");

                    var checkboxes = table2.getElementsByTagName("input");
                    var cells = table1.getElementsByTagName("td");

                    for (var i = 0; i < checkboxes.length; i++) {
                        if (checkboxes[i].checked) {
                            cells[i + 1].innerHTML = "&#10004;"; // Checkmark symbol
                        } else {
                            cells[i + 1].innerHTML = "x";
                        }
                    }

                    toggleTables();
                }
                </script>
            </div>



                    <div>
                        <!-- Calendly inline widget begin -->
                        <div class="calendly-inline-widget" data-url="https://calendly.com/hartwickhealthyhawks?background_color=003249&text_color=00fbff&primary_color=ffffff"></div>
                        <script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>
                        <!-- Calendly inline widget end -->
                    </div>

                    <script>
                $(document).ready(function() {
                    // Save button click event handler
                    $(".save-button").click(function() {
                        var column = $(this).data("column");
                        var dataType = $(this).data("type");

                        if (column === "bio") {
                            // Get the value from the textarea
                            var value = $("#about-me-edit").val();


                        if (dataType === 1) {
                            // Text data type
                            value = $("#" + column).val();
                        } else if (dataType === 2) {
                            // Email data type
                            value = $("#" + column).val();
                            // Perform email validation if needed
                        } else if (dataType === 3) {
                            // Bio (BLOB) data type
                            value = $("#about-me-edit").val();
                        } else if (dataType === 4) {
                            // Favorite (TEXT) data type
                            value = $("#" + column).val();
                        } else if (dataType === 5) {
                            // Availability (TEXT) data type
                            // Code to retrieve availability value
                            value = getAvailabilityValue();
                        } else if (dataType === 6) {
                            // Picture data type
                            var file = document.getElementById("file-upload").files[0];
                            var reader = new FileReader();

                            reader.onloadend = function() {
                                value = reader.result;
                                saveData(column, dataType, value);
                            };

                            if (file) {
                                reader.readAsDataURL(file);
                            }
                            return;
                        }

                        // Call the function to save the data
                        saveData(column, dataType, value);
                    });
                });


                // Define the saveData function
                function saveData(column, dataType, value) {
                    // Perform AJAX request to save the data
                    $.ajax({
                        type: "POST",
                        url: "save_data.php",
                        data: { column: column, dataType: dataType, value: value },
                        success: function(response) {
                            // Handle the success response
                            console.log(response);
                        },
                        error: function(xhr, status, error) {
                            // Handle the error
                            console.log(error);
                        }
                    });
                }
                    </script>



                </div>

        <footer>

            <div class="slideshow-container">

                <div class="mySlides fade">
                    <div class="numbertext">1 / 3</div>
                    <img src="images/campbell1.jpg" style="width:100%">
                    <div class="text">Caption Text</div>
                </div>

                <div class="mySlides fade">
                    <div class="numbertext">2 / 3</div>
                    <img src="images/hutman1.jpg" style="width:100%">
                    <div class="text">Caption Two</div>
                </div>

                <div class="mySlides fade">
                    <div class="numbertext">3 / 3</div>
                    <img src="images/campbell2.jpg" style="width:100%">
                    <div class="text">Caption Three</div>
                </div>

            </div>
            <br>

            <div style="text-align:center">
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>

            <script>
                let slideIndex = 0;
                showSlides();

                function showSlides() {
                    let i;
                    let slides = document.getElementsByClassName("mySlides");
                    let dots = document.getElementsByClassName("dot");
                    for (i = 0; i < slides.length; i++) {
                        slides[i].style.display = "none";
                    }
                    slideIndex++;
                    if (slideIndex > slides.length) { slideIndex = 1 }
                    for (i = 0; i < dots.length; i++) {
                        dots[i].className = dots[i].className.replace(" active", "");
                    }
                    slides[slideIndex - 1].style.display = "block";
                    dots[slideIndex - 1].className += " active";
                    setTimeout(showSlides, 5000); // Change image every 2 seconds
                }
            </script>
        </footer>
    </body>
</html>