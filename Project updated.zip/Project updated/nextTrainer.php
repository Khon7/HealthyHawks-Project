<?php
    session_start();

    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "instructorprofile";

    // creating a connection to the XAMPP database
    $con = mysqli_connect($host, $username, $password, $dbname);

    $sql = "SELECT * FROM profile";
    $rs = mysqli_query($con, $sql);

    if (mysqli_num_rows($rs) > $_SESSION['userID1']) {
        $id = ++$_SESSION['userID1'];

        $sql = "SELECT * FROM profile WHERE id = $id";
        $rs = mysqli_query($con, $sql);

        // Check if the query was successful and if a row was returned
        if ($rs && mysqli_num_rows($rs) > 0) {
            $row = mysqli_fetch_assoc($rs);

            $_SESSION['default'] = true;
            $_SESSION['userID1'] = $row['id'];
            $_SESSION['fullName1'] = $row['fullName'];
            $_SESSION['bio1'] = $row['bio'];
            $_SESSION['fav1'] = $row['fav'];
            $_SESSION['availabilty1'] = $row['availability'];
            $_SESSION['picture1'] = $row['picture'];

            echo "success";
        } else {
            echo "error";
        }

    }


    mysqli_close($con);
?>
