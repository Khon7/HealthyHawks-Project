<!DOCTYPE html>
<html lang="en">
    <head>
        <?php
            session_start();


            if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true) {
                echo $_SESSION['loggedIn'];
                echo $_SESSION['userID'];
                echo $_SESSION['userEmail'];
            }
        ?>
        
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/website.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Montserrat&family=Roboto:wght@300;400;700&display=swap" rel="stylesheet">
        <title>Healthy Hawks </title>
    </head>
<body>
  <div class="navigation-container">
    <img src="images/logohh-smallcopy.png" alt="#"> <!--This will be replaced with an logo-->
    <nav class="site-traverse">
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="profile.php">Instructors</a></li>
        <li><a href="exercises.html">Exercises</a></li>
      </ul>
    </nav>
    <nav class="login-regis">
      <ul>
          <li><a href="regCode.php">Register</a></li>
      </ul>
    </nav>
  </div>
  <div class="hero">
    <h1>Exercises</h1>
  </div>
  <div class="main">
    <div class="filters">
      <form>
        <fieldset>
          <legend>Filters</legend>
          <label>
            <input type="checkbox" name="chest" value="chest" class="filter-checkbox">
            Chest
          </label>
          <label>
            <input type="checkbox" name="arms" value="arms" class="filter-checkbox">
            Arms
          </label>
          <label>
            <input type="checkbox" name="back" value="back" class="filter-checkbox">
            Back
          </label>
          <label>
            <input type="checkbox" name="legs" value="legs" class="filter-checkbox">
            Legs
          </label>
        </fieldset>
      </form>
    </div>
    <section class="strength-exercises">
      <h2>Strength Exercises</h2>
      <div class="exercise-grid">
        <div class="exercise chest">
          <img src="images/spongebob.jpeg" alt="Bench Press">
          <h3>Bench Press</h3>
          <p>Description of Bench Press exercise.</p>
        </div>
        <div class="exercise arms">
          <img src="images/spongebob.jpeg" alt="Bench Press">
          <h3>Tricep Extentions</h3>
          <p>Description of Tricep Extentions exercise.</p>
        </div>
        <div class="exercise back">
          <img src="images/spongebob.jpeg" alt="Bench Press">
          <h3> Barbell Row</h3>
          <p>Description of Barbell Row exercise.</p>
        </div>
        <div class="exercise legs">
          <img src="images/spongebob.jpeg" alt="Push-ups">
          <h3>Back Squat</h3>
          <p>Description of Back Squat exercise.</p>
        </div>
       
        
      </div>
    </section>
    
  </div>
  
  <script src="js/exercises.js"></script>
</body>
</html>