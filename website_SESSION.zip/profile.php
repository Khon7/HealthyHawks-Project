<!DOCTYPE html>
<html lang="en">
    <head>
        <?php

            session_start();

            $host = "localhost";
            $username = "root";
            $password = "";
            $dbname = "instructorprofile";

            // creating a connection to the XAMPP database
            $con = mysqli_connect($host, $username, $password, $dbname);

            // to ensure that the connection is made
            if (!$con)
            {
                die("Connection failed!" . mysqli_connect_error());
            }

            if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && isset($_SESSION['default']) == false) {
                echo "Logged In " . $_SESSION['loggedIn'] . "<br>";
                echo "UserID " . $_SESSION['userID'] . "<br>";


                $id = $_SESSION['userID'];
                $sql = "SELECT * FROM profile WHERE id = '$id'";

                // Send the query to the database
                $rs = mysqli_query($con, $sql);

                // Check if the query was successful and if a row was returned
                if ($rs && mysqli_num_rows($rs) > 0) {
                    $row = mysqli_fetch_assoc($rs);

                    $_SESSION['fullName'] = $row['fullName'];
                    $_SESSION['bio'] = $row['bio'];
                    $_SESSION['availabiltyM1'] = $row['availabilityM'];
                    $_SESSION['availabiltyA1'] = $row['availabilityA'];
                    $_SESSION['availabiltyE1'] = $row['availabilityE'];
                    $_SESSION['picture'] = $row['picture'];

                    $_SESSION['default'] = true;
                    $_SESSION['userID1'] = $row['id'];
                    $_SESSION['fullName1'] = $row['fullName'];
                    $_SESSION['bio1'] = $row['bio'];
                    $_SESSION['availabiltyM1'] = $row['availabilityM'];
                    $_SESSION['availabiltyA1'] = $row['availabilityA'];
                    $_SESSION['availabiltyE1'] = $row['availabilityE'];
                    $_SESSION['picture1'] = $row['picture'];
                }


            } elseif (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && isset($_SESSION['default']) == true) {
                echo "Logged In + Default" . $_SESSION['loggedIn'] . "<br>";
                echo "UserID " . $_SESSION['userID'] . "<br>";
                echo "UserID1 " . $_SESSION['userID1'] . "<br>";
                echo "Picture " . $_SESSION['picture1'] . "<br>";



                //$id = $_SESSION['userID'];
                //$sql = "SELECT * FROM profile WHERE id = '$id'";
                //echo "SQL Query: " . $sql . "<br>";

                //// Send the query to the database
                //$rs = mysqli_query($con, $sql);

                //// Check if the query was successful and if a row was returned
                //if ($rs && mysqli_num_rows($rs) > 0) {
                //    $row = mysqli_fetch_assoc($rs);

                //    $_SESSION['userID'] = $row['id'];
                //    echo $_SESSION['userID'] . "<br>";
                //    $_SESSION['fullName'] = $row['fullName'];
                //    echo $_SESSION['fullName'] . "<br>";
                //    $_SESSION['bio'] = $row['bio'];
                //    $_SESSION['fav'] = $row['fav'];
                //    $_SESSION['availabilty'] = $row['availability'];
                //    $_SESSION['picture'] = $row['picture'];
                //}


            } elseif (isset($_SESSION['default']) == true && $_SESSION['default'] == true) {
                echo "Default " . $_SESSION['default'] . "<br>";
                echo "UserID1 " . $_SESSION['userID1'] . "<br>";


                //$id = $_SESSION['userID'];
                //$sql = "SELECT * FROM profile WHERE id = '$id'";
                //echo "SQL Query: " . $sql . "<br>";

                //// Send the query to the database
                //$rs = mysqli_query($con, $sql);

                //// Check if the query was successful and if a row was returned
                //if ($rs && mysqli_num_rows($rs) > 0) {
                //    $row = mysqli_fetch_assoc($rs);

                //    $_SESSION['userID'] = $row['id'];
                //    echo $_SESSION['userID'] . "<br>";
                //    $_SESSION['fullName'] = $row['fullName'];
                //    echo $_SESSION['fullName'] . "<br>";
                //    $_SESSION['bio'] = $row['bio'];
                //    $_SESSION['fav'] = $row['fav'];
                //    $_SESSION['availabilty'] = $row['availability'];
                //    $_SESSION['picture'] = $row['picture'];
                //}


            } else {
                $_SESSION['default'] = true;

                echo $_SESSION['default'] . "<br>";

                $sql = "SELECT * FROM profile WHERE id = 1";

                // Send the query to the database
                $rs = mysqli_query($con, $sql);
                // Check if the query was successful and if a row was returned
                if ($rs && mysqli_num_rows($rs) > 0) {
                    $row = mysqli_fetch_assoc($rs);

                    $_SESSION['userID1'] = $row['id'];
                    $_SESSION['fullName1'] = $row['fullName'];
                    $_SESSION['bio1'] = $row['bio'];
                    $_SESSION['availabiltyM1'] = $row['availabilityM'];
                    $_SESSION['availabiltyA1'] = $row['availabilityA'];
                    $_SESSION['availabiltyE1'] = $row['availabilityE'];
                    $_SESSION['picture1'] = $row['picture'];

                    echo "Default " . $_SESSION['default'] . "<br>";
                    echo "UserID1 " . $_SESSION['userID1'] . "<br>";
                    echo "Picture " . $_SESSION['picture1'] . "<br>";
                }


            }




        ?>

        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="css/website.css" />
        <script src="instructorScript.js"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Montserrat&family=Roboto:wght@300;400;700&display=swap" rel="stylesheet" />
        <!-- <script defer src="js/carousel.js"></script> -->
        <title>Healthy Hawks</title>
    </head>
    <body>
        <div class="navigation-container">
            <img src="images/logohh-smallcopy.png" alt="#" /><!--This will be replaced with an logo-->
            <nav class="site-traverse">
                <ul>
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="#instructors">Instructors</a>
                    </li>
                    <li>
                        <a href="exercises.php">Exercises</a>
                    </li>
                </ul>
            </nav>
            <nav class="login-regis">
                <ul>
                    <li>
                        <a href="regCode.php">Register</a>
                    </li>
                </ul>
            </nav>
        </div>

        <div class="mainInstuctorDiv">
            <div class="picName">
                <div class="profPic">
                    <div class="profile-picture">
                        <?php
                            $pic = $_SESSION['picture1'];
                            echo "<img class='profilePic' src='$pic' id='profile-img' alt='Profile Picture' />";

                        ?>
                        <br />
                    </div>

                    <!-- Trainer Name -->
                    <div class="profileName">
                        <?php
                        if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && $_SESSION['userID'] == $_SESSION['userID1']) {
                            $fullName = $_SESSION['fullName'];
                            print "<h1 id='name'>$fullName</h1>";

                        } else {
                            $fullName = $_SESSION['fullName1'];
                            print "<h1 id='name'>$fullName</h1>";
                        }

                        ?>
                    </div>
                </div>
            </div>


            <div class="changeTrainer">
                <br>
                <br>
                <button class="prevTrainer" onclick="prevT()">Previous Trainer</button>
                <hr class="half">
                <button class="nextTrainer" onclick="nextT()">Next Trainer</button>


                <script>
                    function prevT() {
                        // Send an AJAX request to a PHP file to fetch the next trainer details
                        var xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                // Handle the response from the PHP file
                                var response = this.responseText;
                                if (response.trim() === 'success') {
                                    // Redirect to the profile.php page
                                    window.location.href = 'profile.php';
                                }
                            }
                        };
                        xhttp.open("GET", "prevTrainer.php", true);
                        xhttp.send();
                    }

                    function nextT() {
                        // Send an AJAX request to a PHP file to fetch the next trainer details
                        var xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                // Handle the response from the PHP file
                                var response = this.responseText;
                                if (response.trim() === 'success') {
                                    // Redirect to the profile.php page
                                    window.location.href = 'profile.php';
                                }
                            }
                        };
                        xhttp.open("GET", "nextTrainer.php", true);
                        xhttp.send();
                    }
                </script>
            </div>

            <!-- Trainer Bio -->
            <div class="about-me">
                <hr>

                <h2>About Me</h2>
                <p class="aboutMeText" id="about-me-display">Enter information about yourself</p>
                <hr class="full">
                <textarea class="aboutMeText" id="about-me-edit" placeholder="Enter information about yourself"></textarea>

                <?php
                if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && $_SESSION['userID'] == $_SESSION['userID1']) {
                    print "<button id='edit-button'>Edit</button>";
                    print "<button class='save-button' id='save-button' data-column='bio'>Save</button>";

                }

                ?>

                <script>
                const displayElement = document.getElementById('about-me-display');
                const editElement = document.getElementById('about-me-edit');
                const editButton = document.getElementById('edit-button');
                const saveButton = document.getElementById('save-button');

                // Show the edit textarea and hide the display paragraph on edit button click
                editButton.addEventListener('click', () => {
                    displayElement.style.display = 'none';
                    editElement.style.display = 'block';
                    editElement.value = displayElement.textContent; // Set the initial textarea value to the displayed text
                });

                // Save the edited text and switch back to display mode on save button click
                saveButton.addEventListener('click', () => {
                    displayElement.textContent = editElement.value;
                    displayElement.style.display = 'block';
                    editElement.style.display = 'none';
                });
                </script>

            </div>

            <div class="access">
                <!--Trainer Hours--> 
                <table id="table1">
                    <tr>
                        <th></th>
                        <th>Monday</th>
                        <th>Tuesday</th>
                        <th>Wednesday</th>
                        <th>Thursday</th>
                        <th>Friday</th>
                    </tr>
                    <tr>
                        <td>Morning</td>
                        <td id="mon-morning">x</td>
                        <td id="tue-morning">x</td>
                        <td id="wed-morning">x</td>
                        <td id="thu-morning">x</td>
                        <td id="fri-morning">x</td>
                    </tr>
                    <tr>
                        <td>Afternoon</td>
                        <td id="mon-afternoon">x</td>
                        <td id="tue-afternoon">x</td>
                        <td id="wed-afternoon">x</td>
                        <td id="thu-afternoon">x</td>
                        <td id="fri-afternoon">x</td>
                    </tr>
                    <tr>
                        <td>Evening</td>
                        <td id="mon-evening">x</td>
                        <td id="tue-evening">x</td>
                        <td id="wed-evening">x</td>
                        <td id="thu-evening">x</td>
                        <td id="fri-evening">x</td>
                    </tr>
                </table>

                <table id="table2" style="display: none;">
                    <tr>
                        <th></th>
                        <th>Monday</th>
                        <th>Tuesday</th>
                        <th>Wednesday</th>
                        <th>Thursday</th>
                        <th>Friday</th>
                    </tr>
                    <tr>
                        <td>Morning</td>
                        <td>
                            <input type="checkbox" id="mon-morning-checkbox" onchange="updateAvailability('mon-morning')" />
                        </td>
                        <td>
                            <input type="checkbox" id="tue-morning-checkbox" onchange="updateAvailability('tue-morning')" />
                        </td>
                        <td>
                            <input type="checkbox" id="wed-morning-checkbox" onchange="updateAvailability('wed-morning')" />
                        </td>
                        <td>
                            <input type="checkbox" id="thu-morning-checkbox" onchange="updateAvailability('thu-morning')" />
                        </td>
                        <td>
                            <input type="checkbox" id="fri-morning-checkbox" onchange="updateAvailability('fri-morning')" />
                        </td>
                    </tr>
                    <tr>
                        <td>Afternoon</td>
                        <td>
                            <input type="checkbox" id="mon-afternoon-checkbox" onchange="updateAvailability('mon-afternoon')" />
                        </td>
                        <td>
                            <input type="checkbox" id="tue-afternoon-checkbox" onchange="updateAvailability('tue-afternoon')" />
                        </td>
                        <td>
                            <input type="checkbox" id="wed-afternoon-checkbox" onchange="updateAvailability('wed-afternoon')" />
                        </td>
                        <td>
                            <input type="checkbox" id="thu-afternoon-checkbox" onchange="updateAvailability('thu-afternoon')" />
                        </td>
                        <td>
                            <input type="checkbox" id="fri-afternoon-checkbox" onchange="updateAvailability('fri-afternoon')" />
                        </td>
                    </tr>
                    <tr>
                        <td>Evening</td>
                        <td>
                            <input type="checkbox" id="mon-evening-checkbox" onchange="updateAvailability('mon-evening')" />
                        </td>
                        <td>
                            <input type="checkbox" id="tue-evening-checkbox" onchange="updateAvailability('tue-evening')" />
                        </td>
                        <td>
                            <input type="checkbox" id="wed-evening-checkbox" onchange="updateAvailability('wed-evening')" />
                        </td>
                        <td>
                            <input type="checkbox" id="thu-evening-checkbox" onchange="updateAvailability('thu-evening')" />
                        </td>
                        <td>
                            <input type="checkbox" id="fri-evening-checkbox" onchange="updateAvailability('fri-evening')" />
                        </td>
                    </tr>
                </table>

                <?php
                    if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true && $_SESSION['userID'] == $_SESSION['userID1']) {
                        print "<button id='editButton' onclick='toggleTables()'>Edit</button>";
                        print "<button onclick='updateAvailability()' style='display: none;'>Save</button>";

                    }
                ?>
                
                <script>
                    // Show the save button when checkboxes are checked
                    var checkboxes = document.querySelectorAll("#table2 input[type='checkbox']");
                    checkboxes.forEach(function(checkbox) {
                        checkbox.addEventListener("change", function() {
                            var saveButton = document.querySelector("button");
                            saveButton.style.display = "block";
                        });
                    });


                    function toggleTables() {
                        var table1 = document.getElementById("table1");
                        var table2 = document.getElementById("table2");
                        var editButton = document.getElementById("editButton");
                        var saveButton = document.getElementById("saveButton");

                        if (table1.style.display === "none") {
                            table1.style.display = "table";
                            table2.style.display = "none";
                            editButton.innerHTML = "Edit";
                            saveButton.style.display = "none";
                        } else {
                            table1.style.display = "none";
                            table2.style.display = "table";
                            editButton.innerHTML = "Save";
                            saveButton.style.display = "block";
                        }
                    }

                    function updateAvailability(id) {
                        var checkbox = document.getElementById(id + "-checkbox");
                        var cell = document.getElementById(id);

                        if (checkbox.checked) {
                            cell.innerHTML = "&#10004;"; // Checkmark symbol
                        } else {
                            cell.innerHTML = "x";
                        }
                    }
                </script>
            </div>

                <div>
                    <!-- Calendly inline widget begin -->
                    <div class="calendly-inline-widget" data-url="https://calendly.com/hartwickhealthyhawks?background_color=003249&text_color=00fbff&primary_color=ffffff"></div>
                    <script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script>
                    <!-- Calendly inline widget end -->
                </div>

                <script>
                    $(document).ready(function() {
                        // Save button click event handler
                        $(".save-button").click(function() {
                            var column = $(this).data("column");
                            var dataType = $(this).data("type");

                            if (column === "bio") {
                                // Get the value from the textarea
                                var value = $("#about-me-edit").val();


                            if (dataType === 1) {
                                // Text data type
                                value = $("#" + column).val();
                            } else if (dataType === 2) {
                                // Email data type
                                value = $("#" + column).val();
                                // Perform email validation if needed
                            } else if (dataType === 3) {
                                // Bio (BLOB) data type
                                value = $("#about-me-edit").val();
                            } else if (dataType === 4) {
                                // Favorite (TEXT) data type
                                value = $("#" + column).val();
                            } else if (dataType === 5) {
                                // Availability (TEXT) data type
                                // Code to retrieve availability value
                                value = getAvailabilityValue();
                            } else if (dataType === 6) {
                                // Picture data type
                                var file = document.getElementById("file-upload").files[0];
                                var reader = new FileReader();

                                reader.onloadend = function() {
                                    value = reader.result;
                                    saveData(column, dataType, value);
                                };

                                if (file) {
                                    reader.readAsDataURL(file);
                                }
                                return;
                            }

                            // Call the function to save the data
                            saveData(column, dataType, value);
                        });
                    });


                    // Define the saveData function
                    function saveData(column, dataType, value) {
                        // Perform AJAX request to save the data
                        $.ajax({
                            type: "POST",
                            url: "save_data.php",
                            data: { column: column, dataType: dataType, value: value },
                            success: function(response) {
                                // Handle the success response
                                console.log(response);
                            },
                            error: function(xhr, status, error) {
                                // Handle the error
                                console.log(error);
                            }
                        });
                    }
                </script>



            </div>
        </div>
        <footer>

            <div class="slideshow-container">

                <div class="mySlides fade">
                    <div class="numbertext">1 / 3</div>
                    <img src="images/campbell1.jpg" style="width:100%">
                    <div class="text">Caption Text</div>
                </div>

                <div class="mySlides fade">
                    <div class="numbertext">2 / 3</div>
                    <img src="images/hutman1.jpg" style="width:100%">
                    <div class="text">Caption Two</div>
                </div>

                <div class="mySlides fade">
                    <div class="numbertext">3 / 3</div>
                    <img src="images/campbell2.jpg" style="width:100%">
                    <div class="text">Caption Three</div>
                </div>

            </div>
            <br>

            <div style="text-align:center">
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>

            <script>
                let slideIndex = 0;
                showSlides();

                function showSlides() {
                    let i;
                    let slides = document.getElementsByClassName("mySlides");
                    let dots = document.getElementsByClassName("dot");
                    for (i = 0; i < slides.length; i++) {
                        slides[i].style.display = "none";
                    }
                    slideIndex++;
                    if (slideIndex > slides.length) { slideIndex = 1 }
                    for (i = 0; i < dots.length; i++) {
                        dots[i].className = dots[i].className.replace(" active", "");
                    }
                    slides[slideIndex - 1].style.display = "block";
                    dots[slideIndex - 1].className += " active";
                    setTimeout(showSlides, 5000); // Change image every 2 seconds
                }
            </script>
        </footer>
    </body>
</html>