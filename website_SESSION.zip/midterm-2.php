<DOCTYPE html>
<html lang="en">
<head>
		<?php 
			include 'midterm.php';
		?>
		<link href="css/midterm-style.css" type="text/css" rel="stylesheet">
	</head>
    <body>
        <?php
            print displayMidtermProgress();
        ?>
    </body>
</html>